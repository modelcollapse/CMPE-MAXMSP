# CMPE Variety Pack for Max — 1.3.0

**Open `CMPE_Variety_Pack.maxpat` in Max.** It contains all five instruments.

Keep this entire `CMPE_Max` folder together. The scripts, voice patches, and
demo samples are required beside the main patch. `START_HERE.html` is the
illustrated short guide; open it in a web browser.

## Start

1. Extract the complete ZIP and close any older copy of the patch.
2. Open `CMPE_Variety_Pack.maxpat` in Max 8 or Max 9.
3. Choose your audio output in the top controls or AUDIO SETUP. Use TEST SOUND
   to check the output.
4. The included demo samples load automatically. Choose an instrument and use
   GENERATE + PLAY for APG/SIOE, or START for ISJS/Many/RMHS.

No third-party externals, Python, or Node.js are needed to play this folder.

## Five instruments

| Instrument | Sources | Behavior |
| --- | --- | --- |
| APG | Three samples | Generates a mirrored audio palindrome |
| ISJS | Three samples | Live grains shaped with a position/density pad |
| Many | Sample 1 | Ambient layers, with 2–4 second fade-ins |
| RMHS | No samples | Harmonic drone, with 3–20 second attacks |
| SIOE | Sample 1 | A rendered short or gradually developing supercut |

## Controls and feedback

LOAD buttons have solid charcoal backgrounds with bold white labels. Rounded
buttons use a distinct accent for each selected instrument: APG blue, ISJS teal,
Many purple, RMHS copper, and SIOE rose. Original-author credit is at the bottom.

Each sample card has a waveform and REC IN button. Select your input device,
then REC IN captures input channels 1 and 2 into that slot for up to 60 seconds.
Press the same button again or STOP to finish. A failed or cancelled take keeps
the previous sample. APG/ISJS share three slots; Many/SIOE use sample 1.
The sample card's SAVE button writes a new recording as a 24-bit WAV. Save new
samples before SAVE SET, which stores their file paths.

APG repeat and pitch fields are larger and have minus/plus step buttons.
Repeat steps are one; pitch-range steps are 0.1. Direct number entry still works.

GENERATE + PLAY builds the finite result and plays it. PLAY reuses the prepared
result. NEW TAKE generates another randomized result and leaves it ready.
STOP/CANCEL stops audio or preparation. The state badge distinguishes loading,
silence checking, rendering, ready, playback, and changes pending.

Drag over either APG/SIOE waveform to select a range. Loop selected range repeats
it; FULL RANGE restores the complete piece. Automatic waveform view scaling only
changes the display, not playback or export level. Live scopes display the
current signal, not a stored recording. The small source waveforms appear as
samples load; the large output waveform appears after generation.

SAVE WAV exports the complete APG/SIOE result as 24-bit stereo WAV. RECORD WAV
captures a live instrument; while stopped it arms capture for START. STOP REC
ends recording while the performance continues. SAVE SET stores settings and
sample paths, not embedded audio or rendered results.

## Included files

The main patch is `CMPE_Variety_Pack.maxpat`. `cmpe_variety.js`, `cmpe_xy.js`, the
three `cmpe_*_voice.maxpat` files, and the three `apgw_test*.wav` files support it.
The `docs` folder contains the usage guide and explicitly labelled interface
previews. `MANIFEST.json` records the version and file hashes.

[Start guide](START_HERE.html) · [Detailed usage](docs/CMPE_USAGE.md) ·
[Attribution](ATTRIBUTION.md) ·
[Source repository](https://github.com/modelcollapse/CMPE-MAXMSP)

## Credit and verification

Original musical ideas and algorithms: **Joo Won Park**.
[Original CMPE project](https://joowonpark.net/cmpe/) ·
[Original APG project](https://joowonpark.net/apg/).

Automated checks cover the models, controller, rendered samples, layout, and
patch connections. Native Max UI, audio output, mouse interaction, and disk
recording still require verification in Max. The interface images are generated
previews, not native Max screenshots.
